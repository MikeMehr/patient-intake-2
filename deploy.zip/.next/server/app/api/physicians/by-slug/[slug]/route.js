var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/physicians/by-slug/[slug]/route.js")
R.c("server/chunks/[root-of-the-server]__0dc8b6bc._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_physicians_by-slug_[slug]_route_actions_5142588e.js")
R.m(86571)
module.exports=R.m(86571).exports
