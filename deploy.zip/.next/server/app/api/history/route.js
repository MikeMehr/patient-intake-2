var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/history/route.js")
R.c("server/chunks/[root-of-the-server]__81334b2c._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/src_lib_1ddbc4f6._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_aec46ce3.js")
R.c("server/chunks/_next-internal_server_app_api_history_route_actions_f1813cd2.js")
R.m(73642)
module.exports=R.m(73642).exports
