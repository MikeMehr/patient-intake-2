var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/pharmacy/route.js")
R.c("server/chunks/[root-of-the-server]__81334b2c._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_72e81301.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_pharmacy_route_actions_f1d281b3.js")
R.m(61173)
module.exports=R.m(61173).exports
