var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/lab-requisitions/editor-save/route.js")
R.c("server/chunks/[root-of-the-server]__ff22b6cf._.js")
R.c("server/chunks/[root-of-the-server]__f1feaa07._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/ce889_server_app_api_lab-requisitions_editor-save_route_actions_e7946ec0.js")
R.m(83164)
module.exports=R.m(83164).exports
