var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/lab-requisitions/editor-session/route.js")
R.c("server/chunks/_123fb999._.js")
R.c("server/chunks/[root-of-the-server]__26e3eccf._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/ce889_server_app_api_lab-requisitions_editor-session_route_actions_ba6809c6.js")
R.m(8213)
module.exports=R.m(8213).exports
