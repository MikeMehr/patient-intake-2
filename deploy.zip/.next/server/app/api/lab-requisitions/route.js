var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/lab-requisitions/route.js")
R.c("server/chunks/[root-of-the-server]__5057e448._.js")
R.c("server/chunks/_d4cd3f16._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_lab-requisitions_route_actions_b7a65c8f.js")
R.m(33630)
module.exports=R.m(33630).exports
