var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/analyze-med-pmh/route.js")
R.c("server/chunks/[root-of-the-server]__199e87e2._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/src_lib_azure-openai_ts_f913c86d._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/_next-internal_server_app_api_analyze-med-pmh_route_actions_0caf4bbb.js")
R.m(50578)
module.exports=R.m(50578).exports
