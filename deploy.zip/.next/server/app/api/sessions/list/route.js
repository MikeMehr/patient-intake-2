var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/sessions/list/route.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__9ece3ee7._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_sessions_list_route_actions_97cdf0e9.js")
R.m(84389)
module.exports=R.m(84389).exports
