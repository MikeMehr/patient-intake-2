var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/sessions/route.js")
R.c("server/chunks/[root-of-the-server]__548c0562._.js")
R.c("server/chunks/_3a230c66._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/_next-internal_server_app_api_sessions_route_actions_c6286fff.js")
R.m(86100)
module.exports=R.m(86100).exports
