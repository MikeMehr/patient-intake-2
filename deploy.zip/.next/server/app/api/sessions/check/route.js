var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/sessions/check/route.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__e54fbac3._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_sessions_check_route_actions_cbaafded.js")
R.m(35869)
module.exports=R.m(35869).exports
