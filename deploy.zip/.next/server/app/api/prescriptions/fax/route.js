var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/prescriptions/fax/route.js")
R.c("server/chunks/[root-of-the-server]__5057e448._.js")
R.c("server/chunks/_cb15c780._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_prescriptions_fax_route_actions_674b0a01.js")
R.m(48299)
module.exports=R.m(48299).exports
