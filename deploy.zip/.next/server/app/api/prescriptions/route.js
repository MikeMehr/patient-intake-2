var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/prescriptions/route.js")
R.c("server/chunks/[root-of-the-server]__bb7f9238._.js")
R.c("server/chunks/_e65c76d7._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_prescriptions_route_actions_6341e723.js")
R.m(12846)
module.exports=R.m(12846).exports
