var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/patients/[patientId]/route.js")
R.c("server/chunks/[root-of-the-server]__856c856d._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_patients_[patientId]_route_actions_7704d106.js")
R.m(32332)
module.exports=R.m(32332).exports
