var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/patients/search/route.js")
R.c("server/chunks/[root-of-the-server]__c38bd045._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_patients_search_route_actions_f231084b.js")
R.m(74319)
module.exports=R.m(74319).exports
