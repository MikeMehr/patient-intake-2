var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/invitations/list/route.js")
R.c("server/chunks/[root-of-the-server]__0ba6aa50._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/_next-internal_server_app_api_invitations_list_route_actions_e847b35a.js")
R.m(58714)
module.exports=R.m(58714).exports
