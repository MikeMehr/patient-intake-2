var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/invitations/[invitationId]/route.js")
R.c("server/chunks/[root-of-the-server]__c52840b0._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/_next-internal_server_app_api_invitations_[invitationId]_route_actions_a2ef619f.js")
R.m(67190)
module.exports=R.m(67190).exports
