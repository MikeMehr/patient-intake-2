var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/invitations/lab-report/route.js")
R.c("server/chunks/[root-of-the-server]__0259e5c0._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_invitations_lab-report_route_actions_6c52797c.js")
R.m(40069)
module.exports=R.m(40069).exports
