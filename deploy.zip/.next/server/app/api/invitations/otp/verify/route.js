var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/invitations/otp/verify/route.js")
R.c("server/chunks/[root-of-the-server]__6a8af26f._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_invitations_otp_verify_route_actions_d603e888.js")
R.m(15844)
module.exports=R.m(15844).exports
