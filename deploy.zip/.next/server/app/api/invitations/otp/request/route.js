var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/invitations/otp/request/route.js")
R.c("server/chunks/[root-of-the-server]__ff77b652._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/node_modules_fd8aff98._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_invitations_otp_request_route_actions_413594bf.js")
R.m(11831)
module.exports=R.m(11831).exports
