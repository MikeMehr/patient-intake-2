var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/invitations/cleanup/route.js")
R.c("server/chunks/[root-of-the-server]__db2a9b49._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_invitations_cleanup_route_actions_bc38cc9a.js")
R.m(93165)
module.exports=R.m(93165).exports
