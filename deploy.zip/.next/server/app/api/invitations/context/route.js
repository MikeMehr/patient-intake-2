var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/invitations/context/route.js")
R.c("server/chunks/[root-of-the-server]__4057dd7e._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_invitations_context_route_actions_cc2bb19b.js")
R.m(18170)
module.exports=R.m(18170).exports
