var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/invitations/open/[token]/route.js")
R.c("server/chunks/[root-of-the-server]__e01d3dab._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_invitations_open_[token]_route_actions_5a682f32.js")
R.m(49622)
module.exports=R.m(49622).exports
