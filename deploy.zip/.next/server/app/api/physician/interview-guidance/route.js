var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/physician/interview-guidance/route.js")
R.c("server/chunks/[root-of-the-server]__aa436283._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/ce889_server_app_api_physician_interview-guidance_route_actions_2c2db950.js")
R.m(68756)
module.exports=R.m(68756).exports
