var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/analyze-form/route.js")
R.c("server/chunks/[root-of-the-server]__23edfafe._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/src_lib_azure-openai_ts_f913c86d._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/_next-internal_server_app_api_analyze-form_route_actions_45e252f6.js")
R.m(83737)
module.exports=R.m(83737).exports
