var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/emr/oscar/patient-lookup/route.js")
R.c("server/chunks/[root-of-the-server]__3f0944bf._.js")
R.c("server/chunks/_e7562f53._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_emr_oscar_patient-lookup_route_actions_076e12ea.js")
R.m(57505)
module.exports=R.m(57505).exports
