var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/emr/oscar/patient-details/route.js")
R.c("server/chunks/[root-of-the-server]__3f0944bf._.js")
R.c("server/chunks/_625cef9e._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_emr_oscar_patient-details_route_actions_90609e5f.js")
R.m(63948)
module.exports=R.m(63948).exports
