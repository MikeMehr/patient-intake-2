var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/me/route.js")
R.c("server/chunks/[root-of-the-server]__5850b9cd._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_me_route_actions_97ac7615.js")
R.m(93025)
module.exports=R.m(93025).exports
