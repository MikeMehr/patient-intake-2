var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/reset-password/[token]/route.js")
R.c("server/chunks/[root-of-the-server]__91fc81ff._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_reset-password_[token]_route_actions_434cba31.js")
R.m(30636)
module.exports=R.m(30636).exports
