var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/reset-password/route.js")
R.c("server/chunks/[root-of-the-server]__878d8e85._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_reset-password_route_actions_727e7a95.js")
R.m(21391)
module.exports=R.m(21391).exports
