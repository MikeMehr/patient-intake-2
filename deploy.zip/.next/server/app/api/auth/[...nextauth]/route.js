var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__9dc52a3c._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/node_modules_next_dist_931d1e37._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_[___nextauth]_route_actions_1c865db8.js")
R.m(3413)
module.exports=R.m(3413).exports
