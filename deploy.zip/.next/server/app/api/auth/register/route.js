var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/register/route.js")
R.c("server/chunks/[root-of-the-server]__2ad25faa._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_register_route_actions_3564e727.js")
R.m(6706)
module.exports=R.m(6706).exports
