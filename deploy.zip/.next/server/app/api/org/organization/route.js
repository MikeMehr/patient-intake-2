var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/org/organization/route.js")
R.c("server/chunks/[root-of-the-server]__3fb70385._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_org_organization_route_actions_97a8659d.js")
R.m(22928)
module.exports=R.m(22928).exports
