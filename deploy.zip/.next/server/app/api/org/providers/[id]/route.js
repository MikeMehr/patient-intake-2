var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/org/providers/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__8ead658b._.js")
R.c("server/chunks/_0f32fcc6._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_org_providers_[id]_route_actions_d18ab860.js")
R.m(647)
module.exports=R.m(647).exports
