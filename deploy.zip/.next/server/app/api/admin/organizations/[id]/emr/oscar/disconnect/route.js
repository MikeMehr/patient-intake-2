var R=require("../../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/organizations/[id]/emr/oscar/disconnect/route.js")
R.c("server/chunks/[root-of-the-server]__a74e45d6._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/bec2d_app_api_admin_organizations_[id]_emr_oscar_disconnect_route_actions_b9d1c2b9.js")
R.m(56758)
module.exports=R.m(56758).exports
