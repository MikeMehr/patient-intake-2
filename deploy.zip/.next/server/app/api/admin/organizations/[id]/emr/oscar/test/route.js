var R=require("../../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/organizations/[id]/emr/oscar/test/route.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__b5175e4b._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/ce889_server_app_api_admin_organizations_[id]_emr_oscar_test_route_actions_817d17af.js")
R.m(12365)
module.exports=R.m(12365).exports
