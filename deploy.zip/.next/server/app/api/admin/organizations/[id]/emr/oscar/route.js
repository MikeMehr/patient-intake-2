var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/organizations/[id]/emr/oscar/route.js")
R.c("server/chunks/[root-of-the-server]__38a2b36e._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/ce889_server_app_api_admin_organizations_[id]_emr_oscar_route_actions_65be44e8.js")
R.m(43187)
module.exports=R.m(43187).exports
