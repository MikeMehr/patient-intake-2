var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/organizations/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__220711bb._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_organizations_[id]_route_actions_806be0dd.js")
R.m(65535)
module.exports=R.m(65535).exports
