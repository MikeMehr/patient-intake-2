var R=require("../../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/organizations/[id]/emr/oscar/connect/route.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__700fc51b._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/bec2d_app_api_admin_organizations_[id]_emr_oscar_connect_route_actions_284d4e03.js")
R.m(37668)
module.exports=R.m(37668).exports
