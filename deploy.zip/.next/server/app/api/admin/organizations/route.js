var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/organizations/route.js")
R.c("server/chunks/[root-of-the-server]__7d224e89._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_organizations_route_actions_54f56e2b.js")
R.m(57472)
module.exports=R.m(57472).exports
