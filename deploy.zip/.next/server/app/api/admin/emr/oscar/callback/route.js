var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/emr/oscar/callback/route.js")
R.c("server/chunks/[root-of-the-server]__466642fc._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_emr_oscar_callback_route_actions_2917e1db.js")
R.m(56061)
module.exports=R.m(56061).exports
