var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/providers/route.js")
R.c("server/chunks/[root-of-the-server]__e41a106e._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_providers_route_actions_7fc65d33.js")
R.m(79278)
module.exports=R.m(79278).exports
