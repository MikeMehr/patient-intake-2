var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/providers/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__8ead658b._.js")
R.c("server/chunks/_b433af59._.js")
R.c("server/chunks/node_modules_next_92aaecbe._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_providers_[id]_route_actions_22e8472e.js")
R.m(5679)
module.exports=R.m(5679).exports
