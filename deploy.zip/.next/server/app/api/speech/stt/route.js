var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/speech/stt/route.js")
R.c("server/chunks/[root-of-the-server]__5209e8e9._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_speech_stt_route_actions_7f2d7e9a.js")
R.m(39048)
module.exports=R.m(39048).exports
