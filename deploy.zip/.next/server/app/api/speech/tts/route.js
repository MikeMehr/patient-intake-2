var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/speech/tts/route.js")
R.c("server/chunks/[root-of-the-server]__0ed00ecf._.js")
R.c("server/chunks/[root-of-the-server]__dcdabaaf._.js")
R.c("server/chunks/node_modules_next_dist_23bfe24c._.js")
R.c("server/chunks/_next-internal_server_app_api_speech_tts_route_actions_4dddcea8.js")
R.m(82023)
module.exports=R.m(82023).exports
